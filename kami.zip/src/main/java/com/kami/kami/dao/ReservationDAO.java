package com.kami.kami.dao;

public class ReservationDAO {

}
