package com.kami.kami.dao;

public interface ChartMapper {

}
