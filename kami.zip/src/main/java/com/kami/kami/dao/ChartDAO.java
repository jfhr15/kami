package com.kami.kami.dao;

public class ChartDAO {

}
