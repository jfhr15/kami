package com.kami.kami.vo;

public class Schedule { //근무일정 등록
	private int scheduleseq;
	private String emp_id; //직원 id
	private String sch_time; //근무시간
	private String sch_startdate; //근무시작일
	private String sch_enddate; //근무종요일
	private String sch_dayofweek; //요일
}
